// ===================================================================
// kohonen network demonstration
// Copyright (c) 2005 Nicolas Rougier
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
// ===================================================================

#ifndef __KOHONEN_H__
#define __KOHONEN_H__

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>


const unsigned int	COLOR_MODE  = 0;
const unsigned int	FILTER_MODE = 1;


int IMG_SavePNG (SDL_Surface *src, char *filename);

void PixelRGBA (SDL_Surface *dst, Sint16 x, Sint16 y,
                Uint8 r=255, Uint8 g=255, Uint8 b=255, Uint8 a=255);

int  StringRGBA(SDL_Surface * dst, Sint16 x, Sint16 y, const char *c,
                Uint8 r=255, Uint8 g=255, Uint8 b=255, Uint8 a=255);

#endif
