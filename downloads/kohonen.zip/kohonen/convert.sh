#!/bin/sh

convert 0GB.ppm 0GB.png
convert 1GB.ppm 1GB.png
convert R0B.ppm R0B.png
convert R1B.ppm R1B.png
convert RG0.ppm RG0.png
convert RG1.ppm RG1.png
