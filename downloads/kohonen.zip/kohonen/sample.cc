// ===================================================================
// kohonen network demonstration
// Copyright (C) 2005 Nicolas Rougier
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
// ===================================================================

#include <cmath>
#include "sample.h"
#include "kohonen.h"

/**
 * Constructor
 *
 * @param size			size of values
 */
Sample::Sample (unsigned int size)
{    
    if (size)
        _value.resize (size);
}

/**
 *
 */
Sample::~Sample (void)
{}

/**
 *
 */
float
Sample::distance (Sample &other)
{
    if (size() != other.size())
        return 1.0f;

    float d = 0;
    for (unsigned int i=0; i<size(); i++)
        d += (_value[i]-other[i])*(_value[i]-other[i]);
    return sqrt(d);
}


/**
 *
 */
void
Sample::geometry (unsigned int width, unsigned int height, unsigned int mode)
{
    if ((!width) || (!height))
        return;

    _width  = width;
    _height = height;
    _mode   = mode;
    
    if (_mode == FILTER_MODE)
        _value.resize (_width*_height);
    else
        _value.resize (_width*_height*3);
}

/**
 *
 */
void
Sample::sample (SDL_Surface *src,
                unsigned int x, unsigned int y)
{

    // If no src is provided, sample is purely random
    if (src == 0) {
        for (unsigned int i=0; i<size(); i++)
            _value[i] = rand()/float(RAND_MAX);
        return;
    }

    unsigned char *pixels = (unsigned char *) src->pixels;

    if (_mode == COLOR_MODE) {
        unsigned char r, g, b;
        unsigned char *p = &pixels[y*src->pitch + x*src->format->BytesPerPixel];
        r = *p++;
        g = *p++;
        b = *p++;
        _value[0] = r/255.0f;
        _value[1] = g/255.0f;
        _value[2] = b/255.0f;
        return;
    }


    for (unsigned int i=0; i<_width; i++) {
        for (unsigned int j=0; j<_height; j++) {
            unsigned char r, g, b;
            unsigned char *p = &pixels[(j+y)*src->pitch + (i+x)*src->format->BytesPerPixel];
            if (SDL_BYTEORDER == SDL_BIG_ENDIAN) {
                r = *p++; g = *p++; b = *p++;
            } else {
                b = *p++; r = *p++; g = *p++;
            }
            _value[j*_width+i] = (0.3*r + 0.59*g + 0.11*b)/255.0f;
        }
    }
}

/**
 * Draw a sample onto a surface using 3 weights (rgb) for one pixel
 * (or more if the given geometry is larger).
 */
void
Sample::draw (SDL_Surface *dst,
              unsigned int x, unsigned int y,
              unsigned int width, unsigned int height,
              bool force)
{
    // Possibly, the provided geometry (width and height) does not fit
    // the size of the prototype, so we have to adapt it to try to fill
    // the whole geometry:
    //
    //  - width*height is the exact number of pixels to draw
    //  - size()/3     is the total number of values we have
    //
    //
    if (_need_redraw || force) {
        float s = size();
        if (_mode == COLOR_MODE)
            s /= 3;

        for (unsigned i=0; i<width; i++) {
            for (unsigned j=0; j<height; j++) {

                int ii = int ((i/float(width))*_width);
                int jj = int ((j/float(height))*_height);

                unsigned int index = jj*_width+ii; // (unsigned int) (((j*width+i)/float(width*height))*s);


                unsigned char r = (unsigned char) (_value[index]*255.0f);
                unsigned char g = r;
                unsigned char b = r;
                
                if (_mode == COLOR_MODE) { 
                    g = (unsigned char) (_value[index+1]*255.0f);
                    b = (unsigned char) (_value[index+2]*255.0f);
                }
                
                PixelRGBA(dst, x+i, y+j, r, g, b);
            }
        }
        _need_redraw = false;
    }    
}
