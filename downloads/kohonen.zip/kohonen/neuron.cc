// ===================================================================
// kohonen network demonstration
// Copyright (C) 2005 Nicolas Rougier
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
// ===================================================================

#include <cmath>
#include "sample.h"
#include "neuron.h"

/**
 * Constructor
 *
 * @param size			size of prototype
 * @param min			minimum value of weights
 * @param max			maximum value of weights
 * @param homogeneous	whether weights are homogenous
 */
Neuron::Neuron (unsigned int width, unsigned height,  unsigned int mode, bool homogeneous)
{    
    _prototype.geometry (width, height, mode);
    _prototype._need_redraw = true;
    
    _min = WEIGHT_MIN;
    _max = WEIGHT_MAX;

    if (homogeneous) {
        float v = _min + (_max-_min)*(rand()/float(RAND_MAX));
        for (unsigned int i = 0; i<size(); i++)
            _prototype[i] = v;
    } else {
        for (unsigned int i = 0; i<size(); i++)
            _prototype[i] = _min + (_max-_min)*(rand()/float(RAND_MAX));
    }
}



/**
 *
 */
Neuron::~Neuron (void)
{}


/**
 *
 */
unsigned int
Neuron::size (void)
{
    return _prototype.size();
}

/**
 *
 */
float
Neuron::distance (Sample &sample)
{
    return _prototype.distance (sample);
}


/**
 * Learn a given amount of a new sample
 *
 * sample			sample to learn
 * amount			amount of learning
 */
void
Neuron::learn (Sample &sample, float amount)
{
    if (sample.size() != size())
        return;

    for (unsigned int i=0; i<size(); i++)
        //        _prototype[i] += amount * (sample[i] - _prototype[i]);
        _prototype[i] = (1-amount)*_prototype[i] + amount * sample[i];
    _prototype._need_redraw = true;
}


/**
 * Draw a neuron onto a surface using 3 weights (rgb) for one pixel
 * (or more if the given geometry is larger).
 */
void
Neuron::draw (SDL_Surface *dst,
              unsigned int x, unsigned int y,
              unsigned int width, unsigned int height,
              bool force)
{
    _prototype.draw (dst, x, y, width, height, force);
}
