// ===================================================================
// kohonen network demonstration
// Copyright (C) 2005 Nicolas Rougier
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
// ===================================================================

#include <cmath>
#include "kohonen.h"
#include "network.h"

/**
 * Constructor
 *
 * @param size			size of values
 */
Network::Network (unsigned int width, unsigned int height,
                  unsigned int unit_width, unsigned int unit_height,
                  unsigned int mode, float lrate, float w)
{

    for (unsigned int i = 0; i < width*height; i++)
        _neuron.push_back (Neuron(unit_width, unit_height, mode, true));
    
    _sample.geometry (unit_width, unit_height, mode);

    _width = width;
    _height = height;
    _mode = mode;
    _epochs = 0;
    _lrate = lrate;
    _w = w;
}

/**
 *
 */
Network::~Network (void)
{}
    
/**
 *
 */
void
Network::sample (SDL_Surface *src)
{
    if (src) {
        _x = int (rand()/float(RAND_MAX) * (src->w - _sample.width()));
        _y = int (rand()/float(RAND_MAX) * (src->h - _sample.height()));
/*
        _x = int ((rand()/float(RAND_MAX)) *  int(src->w/_sample.width()));
        _x *= _sample.width();
        _y = int ((rand()/float(RAND_MAX)) *  int(src->h/_sample.height()));
        _y *= _sample.height();
*/

    }
    _sample.sample (src,_x,_y);
}

/**
 *
 */
void
Network::compete (void)
{
    if (!size())
        return;

    float min_d = _neuron[0].distance (_sample);
    _winner = 0;
    for (unsigned int i=1; i<size(); i++) {
        float d = _neuron[i].distance (_sample);
        if (d < min_d) {
            min_d = d;
            _winner = i;
        }
    }
}


/**
 *
 */
void
Network::learn (float lrate)
{
    if (!size())
        return;

    compete();
    
    int winner_x = _winner % _width;
    int winner_y = _winner / _width;
    for (unsigned int i=0; i<_width; i++) {
        for (unsigned int j=0; j<_height; j++) {
            int x = winner_x-i;
            int y = winner_y-j;
            float g = exp (-(x*x+y*y)/(_w*_w));
            if (g > 0.1)
                _neuron[j*_width+i].learn (_sample, lrate * g);
        }
    }
    _epochs++;
}

/**
 *
 */
void
Network::draw (SDL_Surface *dst,
               unsigned int x, unsigned int y,
               unsigned int width, unsigned int height)
{
    // Compute allocated size for each neuron
    int nw = width/_width-1;
    int nh = height/_height-1;
    
    if ((nw < 1) || (nh < 1))
        return;

    for (unsigned int i=0; i<_width; i++)
        for (unsigned int j=0; j<_height; j++)
            _neuron[j*_width+i].draw (dst, x + i*(nw+1), y + j*(nh+1), nw, nh);
    
    //if (_mode == FILTER_MODE)
    //    _neuron[_winner].draw (dst, _x, _y, _sample.width(), _sample.height(), true);
}

/**
 *
 */
void
Network::print (SDL_Surface *src, SDL_Surface *dst)
{
    unsigned int dx = _sample.width();
    unsigned int dy = _sample.height();
    if (_mode == COLOR_MODE) {
        dx = 1;
        dy = 1;
    } 


    for (unsigned int y=0; y <= (src->h-dy); y+= dy) {
        SDL_LockSurface(dst);
        for (unsigned int x=0; x <= (src->w-dx); x += dx) {
            _sample.sample (src, x, y);
            compete();
            _neuron[_winner].draw (dst, x, y, _sample.width(), _sample.height(), true);
        }
        SDL_Flip(dst);            
        SDL_UnlockSurface(dst);
    }
}


/**
 *
 */
void
Network::reconstruct (SDL_Surface *image, char *filename)
{
    SDL_Surface *src = SDL_CreateRGBSurface (SDL_SWSURFACE, image->w, image->h,
                                             image->format->BitsPerPixel,
                                             image->format->Rmask,
                                             image->format->Gmask,
                                             image->format->Bmask,
                                             image->format->Amask);
    SDL_BlitSurface (image, 0, src, 0);

    unsigned int dx  = _sample.width();
    unsigned int dy = _sample.height();
    if (_mode == COLOR_MODE) {
        dx = 1;
        dy = 1;
    } 

    for (unsigned int x=0; x <= (src->w-dx); x += dx) {
        for (unsigned int y=0; y <= (src->h-dy); y+= dy) {
            _sample.sample (src, x, y);
            compete();
            _neuron[_winner].draw (src, x, y, _sample.width(), _sample.height(), true);
        }
    }
    IMG_SavePNG(src, filename);
    SDL_FreeSurface (src);
}
