// ===================================================================
// kohonen network demonstration
// Copyright (C) 2005 Nicolas Rougier
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
// ===================================================================
//
// Compile with:
// g++ -O3 sample.cc neuron.cc network.cc kohonen.cc -o kohonen `sdl-config --cflags --libs` -lSDL_image -Wall
// g++ -g sample.cc neuron.cc network.cc kohonen.cc -o kohonen `sdl-config --cflags --libs` -lSDL_image -Wall
//
// Start with (for example):
// ./kohonen -mode filter -image lena.png -size 16 -usize 16 -epochs 25000
//  for a network of 16x16 neurons with filter size of 16x16
//  running for 25000 epochs before pausing
//  then press space to start another run of 25000 epochs
//
// Start with (for example):
// ./kohonen -mode color -size 64 -exp_w 7 -epochs 5000
//  for a network of 40x40 neurons with color filter
//  running for 25000 epochs before pausing
//  then press space to start another run of 25000 epochs
//
//
// At anytime you can press:
//  's' for screenshot (will be saved in 'screenshot-xx.png')
//  'r' for reconstruction (will be saved in 'reconstructed-xx.png')
//
// ===================================================================

#include <vector>
#include <string>
#include <cmath>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <png.h>

#include "kohonen.h"
#include "network.h"
#include "font.h"


int
main (int argc, char **argv) {

    // Default paremeters
    std::string filename= "";
    int size			= 16;
    int usize			= 16;
    int epochs			= 25000;
    float exp_w			= sqrt(3.0f);
    float lrate			= 0.1f;
    unsigned int mode	= COLOR_MODE;
    int seed            = int(time(0));
    int zoom			= 1;

    int screen_width	= 0;
    int screen_height	= 0;
    int net_x			= 0;
    int net_y			= 0;
    int net_width		= 0;
    int net_height		= 0;


    // Usage
    if (argc < 3) {
        printf ("Usage: kohonen -image <file> [-size n] "
                "[-usize n] [-epochs n] [-lrate f] [-exp_w f] "
                "[-mode color|filter] [-seed n] [-zoom n]\n");
        exit (EXIT_FAILURE);
    }

    // Argument parsing
    for (int i=1; i<argc; i+=2) {
        std::string arg   = argv[i];
        
        if (arg == "-image")
            filename = argv[i+1];
        else if (arg == "-size")
            sscanf (argv[i+1], "%d", &size);
        else if (arg == "-usize")
            sscanf (argv[i+1], "%d", &usize);
        else if (arg == "-epochs")
            sscanf (argv[i+1], "%d", &epochs);
        else if (arg == "-lrate")
            sscanf (argv[i+1], "%f", &lrate);
        else if (arg == "-exp_w")
            sscanf (argv[i+1], "%f", &exp_w);
        else if (arg == "-seed")
            sscanf (argv[i+1], "%d", &seed);
        else if (arg == "-zoom")
            sscanf (argv[i+1], "%d", &zoom);
        else if (arg == "-mode") {
            std::string arg2 =argv[i+1];
            if (arg2 == "color")
                mode = COLOR_MODE;
            else
                mode= FILTER_MODE;
        }
    }

    if (zoom < 1)
        zoom = 1;
    
    if ((mode == FILTER_MODE) && (filename == ""))
        filename = "lena.jpg";
        

    if (mode == COLOR_MODE)
        usize = 1;

    // Display simulation parameters
    printf("Simulation parameters:\n");
    printf("----------------------\n");
    printf("Simulation mode:         ");
    if (mode == COLOR_MODE)
        printf ("color\n");
    else
        printf ("filter\n");
    printf("Input:                   %s\n", filename.c_str());
    printf("Network size:            %dx%d (%d)\n", size, size, size*size);
    printf("Neuron  size:            %dx%d (%d)\n", usize, usize, usize*usize);
    printf("Neighbourhood function:  exp(-d*d/%.2f)\n", exp_w);
    printf("Learning rate:           %.3f\n", lrate);
    printf("Number of epochs to run: %d\n", epochs);
    printf("Random seed:             %d\n", seed);


    // Load image if necessary
    SDL_Surface *image = 0;
    if (filename != "") {
        image = IMG_Load (filename.c_str());
        if (image == NULL) {
            printf ("Image loading failed: %s\n", SDL_GetError());
            exit (EXIT_FAILURE);
        } 
        if (image->format->BitsPerPixel != 24) {
            printf ("This sotware only accept 24 bits images\n");
            exit (EXIT_FAILURE);
        }        
    }
    

    // SDL init
    if (SDL_Init (SDL_INIT_VIDEO) < 0) {
	    printf ("Video initialization failed: %s\n", SDL_GetError());
		SDL_Quit();
		exit (EXIT_FAILURE);
	}

    const SDL_VideoInfo *info;
    if ((info = SDL_GetVideoInfo()) == 0) {
	    printf ("Video query failed: %s\n", SDL_GetError());
		SDL_Quit();
		exit (EXIT_FAILURE);
	}

    unsigned int flags;    
    if (info->hw_available) flags = SDL_HWSURFACE;
    else                    flags = SDL_SWSURFACE;
    if (info->blit_hw)      flags = SDL_HWACCEL;
	flags |= SDL_DOUBLEBUF;



    // screen size computation
    if (image) {
        screen_width  += image->w + 1;
        screen_height += image->h + 1;
        net_x = image->w+1;
    }

    if (mode == COLOR_MODE) {
        net_width  = size * zoom;
        net_height = size * zoom;
    } else {
        net_width = size * (usize+1) * zoom;
        net_height= size * (usize+1) * zoom;
    }
    
    screen_width  += net_width;
    screen_height = (screen_height > net_height) ? screen_height : net_height;
    

    // screen (window) init
    SDL_Surface *screen = 0;
    if ((screen = SDL_SetVideoMode (screen_width, screen_height, 24, flags)) == 0) {
	    printf ("Video mode set failed: %s\n", SDL_GetError());
		SDL_Quit();
		exit (EXIT_FAILURE);
	}
    
    if (image)
        SDL_BlitSurface(image, 0, screen, 0);


    // Network init
    srand (seed);
    Network *net = new Network (size, size, usize, usize, mode, lrate, exp_w);


    char title[256];
    int done = 0;
    int pause = 0;
    while (done == 0)
        {
            if (net->epochs() && !(net->epochs() % epochs))
                pause = 1;

            SDL_Event event;
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT)
                    done = 1;

                if (event.type == SDL_KEYDOWN) {
                    
                    if (event.key.keysym.sym == SDLK_ESCAPE)
                        done = 1;

                    else if (event.key.keysym.sym == SDLK_s) {
                        char filename[256];
                        for (int i=0; i<100; i++) {
                            sprintf (filename, "screenshot-%.2d.png", i);
                            FILE *file = fopen (filename, "r");
                            if (file == NULL)
                                break;
                        }
                        printf ("Saving screenshot as \"%s\"\n", filename);
                        IMG_SavePNG (screen, filename);
                        printf ("Done !\n");
                    }                    

                    else if (event.key.keysym.sym == SDLK_p)
                        net->print (image, screen);
                    
                    else if (event.key.keysym.sym == SDLK_r) {
                        if (image) {
                            char filename[256];
                            for (int i=0; i<100; i++) {
                                sprintf (filename, "reconstructed-%.2d.png", i);
                                FILE *file = fopen (filename, "r");
                                if (file == NULL)
                                    break;
                            }
                            printf ("Saving reconstructed image at \"%s\"\n", filename);
                            net->reconstruct (image, filename);
                            printf ("Done !\n");
                        }
                    }                    

                    else if (event.key.keysym.sym == SDLK_SPACE)
                        pause = 1-pause;
                }
            }

            if (!pause) {
                float cur_lrate = lrate * (1.0f - (net->epochs()/float(epochs)));
                net->sample (image);
                net->learn (cur_lrate);

                sprintf (title, "kohonen - epoch %ld - lrate %.3f", net->epochs(), cur_lrate);
                SDL_WM_SetCaption (title, NULL);

                SDL_LockSurface(screen);
                net->draw (screen, net_x, net_y, net_width, net_height);
                SDL_UnlockSurface(screen);
                SDL_Flip(screen);
            }
        }

    SDL_Quit ();
    exit (EXIT_SUCCESS);
	return 0;
}



// ===================================================================
//
//    SDL Stuff
//
// ===================================================================
int
IMG_SavePNG (SDL_Surface *src, char *filename)
{
    SDL_Surface *srcRGB =  SDL_CreateRGBSurface (SDL_SWSURFACE, src->w, src->h, 24,
                                                 0xFF000000, 0x0000FF00, 0x00FF0000, 0x000000FF);
    SDL_BlitSurface (src, 0, srcRGB, 0);
    unsigned char *pixels = (unsigned char *) srcRGB->pixels;

    png_bytep *row_pointers = new png_bytep[srcRGB->h];
	for (int i=0; i<srcRGB->h; i++)
        row_pointers[i] = (png_bytep) (pixels + i*srcRGB->pitch);

	FILE *fp = fopen (filename, "wb");
	png_structp png_ptr = png_create_write_struct (PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (!png_ptr)
		return 0;
	png_infop info_ptr = png_create_info_struct (png_ptr);
    if (!info_ptr)
		return 0;
	if (setjmp (png_jmpbuf (png_ptr)))
        return 0;
	png_init_io(png_ptr, fp);
    if (setjmp (png_jmpbuf (png_ptr)))
		return 0;

    png_set_compression_level (png_ptr, Z_BEST_SPEED);
    //    png_set_compression_level (png_ptr, Z_BEST_COMPRESSION);
	png_set_IHDR (png_ptr, info_ptr, srcRGB->w, srcRGB->h,
                  8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
                  PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);
    png_write_info (png_ptr, info_ptr);

	if (setjmp (png_jmpbuf (png_ptr)))
		return 0;
	png_write_image (png_ptr, row_pointers);
	if (setjmp (png_jmpbuf (png_ptr)))
        return 0;
	png_write_end(png_ptr, NULL);
    fclose(fp);

    delete [] row_pointers;
    SDL_FreeSurface (srcRGB);
    
    return 1;
}


void
PixelRGBA (SDL_Surface *dst, Sint16 x, Sint16 y, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
{
    Uint32 color = SDL_MapRGBA(dst->format, r, g, b, a);
    int bpp;
    Sint8 *p;

    bpp = dst->format->BytesPerPixel;
    p = (Sint8 *) dst->pixels + y * dst->pitch + x * bpp;
    switch (bpp)
        {
        case 1:
            *p = color;
            break;
        case 2:
            *(Sint16 *) p = color;
            break;
        case 3:
            if (SDL_BYTEORDER == SDL_BIG_ENDIAN) {
                p[0] = (color >> 16) & 0xff;
                p[1] = (color >> 8) & 0xff;
                p[2] = color & 0xff;
            } else {
                p[0] = color & 0xff;
                p[1] = (color >> 8) & 0xff;
                p[2] = (color >> 16) & 0xff;
            }
            break;
        case 4:
            *(Sint32 *) p = color;
            break;
        }
}


static SDL_Surface *DefaultFont[256];
static Uint32 DefaultFontColor[256];
static const unsigned char *currentFontdata = DefaultFontdata;
static int charWidth = 8, charHeight = 8;
static int charSize = 8;


int CharacterColor(SDL_Surface * dst, Sint16 x, Sint16 y, char c, Uint32 color)
{
    Sint16 left, right, top, bottom;
    Sint16 x1, y1, x2, y2;
    SDL_Rect srect;
    SDL_Rect drect;
    int result;
    int ix, iy;
    const unsigned char *charpos;
    Uint8 *curpos;
    int forced_redraw;
    Uint8 patt, mask;

    /*
     * Get clipping boundary 
     */
    left = dst->clip_rect.x;
    right = dst->clip_rect.x + dst->clip_rect.w - 1;
    top = dst->clip_rect.y;
    bottom = dst->clip_rect.y + dst->clip_rect.h - 1;

    /*
     * Test if bounding box of character is visible 
     */
    x1 = x;
    x2 = x + charWidth;
    y1 = y;
    y2 = y + charHeight;
    if ((x1<left) && (x2<left)) {
     return(0);
    } 
    if ((x1>right) && (x2>right)) {
     return(0);
    } 
    if ((y1<top) && (y2<top)) {
     return(0);
    } 
    if ((y1>bottom) && (y2>bottom)) {
     return(0);
    } 

    /*
     * Setup source rectangle
     */
    srect.x = 0;
    srect.y = 0;
    srect.w = charWidth;
    srect.h = charHeight;

    /*
     * Setup destination rectangle
     */
    drect.x = x;
    drect.y = y;
    drect.w = charWidth;
    drect.h = charHeight;

    /*
     * Create new charWidth x charHeight bitmap surface if not already present 
     */
    if (DefaultFont[(unsigned char) c] == NULL) {
        DefaultFont[(unsigned char) c] =
            SDL_CreateRGBSurface(SDL_SWSURFACE | SDL_HWSURFACE | SDL_SRCALPHA,
                                 charWidth, charHeight, 32,
                                 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF);
        if (DefaultFont[(unsigned char) c] == NULL)
            return (-1);
        forced_redraw = 1;
    } else {
        forced_redraw = 0;
    }
    
    if ((DefaultFontColor[(unsigned char) c] != color) || (forced_redraw)) {
        SDL_SetAlpha(DefaultFont[(unsigned char) c], SDL_SRCALPHA, 255);
        DefaultFontColor[(unsigned char) c] = color;
        
        charpos = currentFontdata + (unsigned char) c * charSize;
        curpos = (Uint8 *) DefaultFont[(unsigned char) c]->pixels;
        
        patt = 0;
        for (iy = 0; iy < charHeight; iy++) {
            mask = 0x00;
            for (ix = 0; ix < charWidth; ix++) {
                if (!(mask >>= 1)) {
                    patt = *charpos++;
                    mask = 0x80;
                }
                
                if (patt & mask)
                    *(Uint32 *)curpos = color;
                else
                    *(Uint32 *)curpos = 0;
                curpos += 4;;
            }
        }
    }
    
    result = SDL_BlitSurface(DefaultFont[(unsigned char) c], &srect, dst, &drect);
    
    return (result);
}

int CharacterRGBA(SDL_Surface * dst, Sint16 x, Sint16 y, char c, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
{
    return (CharacterColor(dst, x, y, c, ((Uint32) r << 24) | ((Uint32) g << 16) | ((Uint32) b << 8) | (Uint32) a));
}

int StringColor(SDL_Surface * dst, Sint16 x, Sint16 y, const char *c, Uint32 color)
{
    int result = 0;
    int curx = x;
    const char *curchar = c;
 
    while (*curchar) {
        result |= CharacterColor(dst, curx, y, *curchar, color);
        curx += charWidth;
        curchar++;
    }

    return (result);
}

int StringRGBA(SDL_Surface * dst, Sint16 x, Sint16 y, const char *c, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
{
    return (StringColor(dst, x, y, c, ((Uint32) r << 24) | ((Uint32) g << 16) | ((Uint32) b << 8) | (Uint32) a));
}
