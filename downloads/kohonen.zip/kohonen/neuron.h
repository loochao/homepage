// ===================================================================
// kohonen network demonstration
// Copyright (c) 2005 Nicolas Rougier
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
// ===================================================================

#ifndef __NEURON_H__
#define __NEURON_H__

#include "kohonen.h"
#include "sample.h"

const float	WEIGHT_MIN = 0.0f;
const float	WEIGHT_MAX = 1.0f;


class Neuron {
 public:
    Neuron (unsigned int width, unsigned int height,
            unsigned int mode = COLOR_MODE, bool homogeneous = true);
    ~Neuron (void);

    unsigned int size (void);
    float distance (Sample &sample);
    void learn (Sample &sample, float amount);
    void draw (SDL_Surface *dst,
               unsigned int x, unsigned int y,
               unsigned int width, unsigned int height,
               bool force=false);
    
 private:
    Sample			_prototype;		// = weights
    float			_min;			// min value
    float			_max;			// max value
};

#endif
