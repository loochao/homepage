// ===================================================================
// kohonen network demonstration
// Copyright (c) 2005 Nicolas Rougier
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
// ===================================================================

#ifndef __NETWORK_H__
#define __NETWORK_H__

#include <vector>
#include "sample.h"
#include "neuron.h"

class Network {
 public:
    Network (unsigned int width, unsigned int height,
             unsigned int unit_width, unsigned int unit_height,
             unsigned int mode, float lrate, float w);
    ~Network (void);
    
    
    unsigned int size (void)		{return _neuron.size();}
    unsigned long epochs (void)		{return _epochs;}
    float &lrate (void)				{return _lrate;}
    unsigned int width (void)		{return _width;}
    unsigned int height (void)		{return _height;}
    Sample &sample (void)			{return _sample;}

    void sample (SDL_Surface *src);
    void compete (void);
    void learn (float lrate);
    void draw (SDL_Surface *dst,
               unsigned int x, unsigned int y,
               unsigned int width, unsigned int height);
    void print (SDL_Surface *src, SDL_Surface *dst);

    void reconstruct (SDL_Surface *src, char *filename);

 private:
    unsigned long		_epochs;
    float				_lrate;
    float				_w;
    float				_current_lrate;
    std::vector<Neuron>	_neuron;
    Sample				_sample;
    unsigned int		_width;
    unsigned int		_height;
    unsigned int		_mode;
    unsigned int		_winner;
    unsigned int		_x, _y;
};

#endif
